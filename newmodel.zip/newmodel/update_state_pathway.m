function [cn,TCM_c] = update_state_pathway(qi,s_n,PT_1,options)

%% Transition probability matrix for ON-OFF
q  = [1-qi(1) qi(1);
      1-qi(2) qi(2)];%[00 01;10 11]
  
P0 = [1-qi(3) qi(3)];%[*0,*1]

%% Generated measurements
IT = PT_1(end,:);
PT_0 = eye(size(PT_1,2));

F = nan(2,options.N);
F(:,1) = [IT(s_n(1));IT(s_n(1))];

for n=2:options.N
    F(1,n) = log(PT_0(s_n(n-1),s_n(n))+eps);
    F(2,n) = log(PT_1(s_n(n-1),s_n(n))); %change the name
end

F = max( exp( bsxfun(@minus,F,max(F)) ), realmin );

%keyboard

%% Forward Filter Step 1
n = 1;

F(:,n) = softmax(log(F(:,n))+log( P0'));

%% Rest of Forward Filtering Steps
for n=2:+1:options.N
    F(:,n) = softmax(log(F(:,n))+log(q'*F(:,n-1)));
end

%% Backward sampling
cn = nan(1,options.N);
cn(options.N) = sample_categorical( F(:,options.N));

for n =options.N-1:-1:1
    cn(n) = sample_categorical( F(:,n) .* q(:,cn(n+1)) );
end

%% Transition counts
TCM_c = zeros( 3, 2 );

TCM_c( 3, cn(1) ) = 1;
for n = 2:options.N
    TCM_c( cn(n-1), cn(n) ) = TCM_c( cn(n-1), cn(n) ) + 1;
end     

cn = cn-1;
%keyboard
% cn    = options.ground.cn;
% TCM_c = options.ground.TCM_c;
% 
% figure(2)
% stairs(cn,'.-')
% ylim([-0.1 1.1])
% drawnow



end

