function exportchainstructure( chainstructure,downsamprate,nameit)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here

maxsample   = ceil(chainstructure.size*(downsamprate));
minsample   = 1;
samplenum   = 1: 1: maxsample;
mem         = chainstructure.gbytes;
parameters  = chainstructure.parameters;
ext         = chainstructure.ext(samplenum,:);
%xi          = chainstructure.xi(samplenum,:);
% rho         = chainstructure.rho(samplenum,:);
s           = chainstructure.s_n(samplenum,:);

IT          = chainstructure.IT(samplenum,:);
DT          = chainstructure.DT(samplenum,:);
SBMT        = chainstructure.SBMT(samplenum,:);
SPMT        = chainstructure.SPMT(samplenum,:);
SBMT1       = chainstructure.SBMT1(samplenum,:);
SPMT1       = chainstructure.SPMT1(samplenum,:);
tau         = chainstructure.tau(samplenum);
STCM        = chainstructure.STCM(samplenum,:);
ufirst3rd   = chainstructure.zsample.u;
maxpost     = chainstructure.part6(samplenum); %No rho
% maxpost2    = chainstructure.part62(samplenum); %Includes rho
% maxpost2    = chainstructure.part62(samplenum); %Includes rho
save([nameit,'.mat'],'parameters','maxpost','s','ext','mem','tau','IT','DT','SBMT','SPMT','SBMT1','SPMT1','STCM','ufirst3rd','-v7.3');
%v7-3 is for data >2gb
disp([nameit,'.mat','--missionaccomplished']);
