function [pp1,pp2] = dirrnd_log_init(rs)
pp  = randg(rs)+realmin;
pp2 = bsxfun(@rdivide,pp,sum(pp,2) );
pp1 = log(pp2);
