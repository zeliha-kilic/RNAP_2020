function [ground,z,units] = synthetic_data(tag)
addpath('pentadiag')
if isequal(tag,1)
    M = 55;%total number of states,length of the his plasmids
    tau1 = 1;%variance of the measurement noise
    tau = 1/(0.33)^2; %this is the precision(nm^-2)
    tau_err = 1/(1/100)^2;
    lstar =8;
    mu = 0.5;%mean of the measurement(nm)
    eta = 3;
    beta = 0.1;
    l_const = 33/100;%constant periodicity(nm)
    t_final = 20;%final time of the elongation in seconds
    t_dwell = .007;%dwell time in a state
    dt = 0.00125;%data acquisition time stepping in seconds
    p0 = 1; %this is also in bps, location of the promoter
end
N       = floor(t_final/dt);
ttable  = (1:N)*dt;
%% Transition matrix
c       = 0.999;
b       = 0.99;
a       = 0.999;
P1      = pentadiag(M,a,b,c);
IC      = ( (1/M)*( ones(1,M) ) );%Initial condition
P       = [P1; IC]; %augmented transition matrix

%% Extension of the tether
F       = (0:M-1)*(33/100);

%% State space
s1      = nan(1,N);
s1(1)   = 1;
for n   = 2:N
  s1(n) = sample_categorical(P(s1(n-1),:));%it samples based onthe rows of the transition matrix
end
TCM     = zeros( M + 1, M );

TCM( M +1, s1(1) ) = 1;
for n   = 2:N
  TCM( s1(n-1), s1(n) ) = TCM( s1(n-1), s1(n) ) + 1;
end


%% Measurement of the extension of the tether
z       = nan(1,N);
sigma   = 1/sqrt(tau);
z(1)    = (lstar + F(s1(1))+ sigma*randn(1));
for n   = 2:N
  z(n)  = (F(s1(n))) + lstar + sigma * randn(1); %RNAP elongation(nm)
end

while ~(ceil(1.4*(max(z)-min(z))*100/33)>=M)
    s1(1)   = 1;
    for n   = 2:N
        s1(n) = sample_categorical(P(s1(n-1),:));%it samples based onthe rows of the transition matrix
    end
    TCM     = zeros( M + 1, M );

	CM( M +1, s1(1) ) = 1;
    for n   = 2:N
    TCM( s1(n-1), s1(n) ) = TCM( s1(n-1), s1(n) ) + 1;
    end
    z       = nan(1,N);
    sigma   = 1/sqrt(tau);
    z(1)    = (lstar + F(s1(1))+ sigma*randn(1));
    for n   = 2:N
    z(n)  = (F(s1(n))) + lstar + sigma * randn(1); %RNAP elongation(nm)
    end
end
units.time    = 's';
units.space   = 'nm';
ground.s      = s1;
ground.TCM    = TCM;
ground.F      = F;
ground.M      = M;
ground.IC     = IC;
ground.P      = P;
ground.dt     = dt;

%% Plotting the data
tind    = t_final-([100 1]+40)*t_dwell;
ind     = ttable>=tind(1) & ttable<=tind(2);

figure(4)

subplot(1,4,1)
h       =plot(ttable, (F(s1)+lstar), 'b.-',...
ttable,z,'c.-');
xlim([0 t_final+dt])
ylim([min(z)-eps max(z)+eps])
%legend([h(1) h(2)],'RNAP motion','Simulated data','orientation','horizontal','location','northoutside');
uistack(h(1),'top');
ylabel(['Extension (nm)'])
xlabel(['Time (sec)'])

subplot(1,4,2)
ylim(get(gca,'YLim'))
histogram(z,linspace(min(z),max(z),100),'orientation','horizontal','normalization','pdf');
ylim([min(z)-eps max(z)+eps])
xlabel(['PDF'])

subplot(1,4,3)
l_const  = 33/100;
h1=plot(ttable, (F(s1)+lstar)*100/33, 'b.-',...
ttable,z*(100/33),'c--');
xlim([0 t_final+dt])
ylim([min(z*(100/33)) max(z*(100/33))+1])
line(get(gca,'XLim'),[ max(z*(100/33))+1; max(z*(100/33))+1]*F*(100/33),'color','k','linestyle',':')
line(200*tind ,[ max(z*(100/33))+1; max(z*(100/33))+1]*F*(100/33),'color','k','linestyle',':')
line([1;1]*tind,get(gca,'YLim'),'color','r','linestyle','--')
l1 = line(get(gca,'XLim'),[1;1]*F*100/33,'color','k','linestyle',':')
leg = legend([h1(1) h1(2) l1(1)],'RNAP motion','Simulated data','States','orientation','horizontal','location','northoutside')
leg.Position = [0.141071431699728,0.932281757778846,0.557142848681127,0.035714284933749];
uistack(h1(1),'top')
legend boxon
box on
ylabel(['Extension (bp)'])
xlabel(['Time (sec)'])
      
     
subplot(1,4,4)
plot(ttable(ind),(F(s1(ind))+lstar),'b.-',...
ttable(ind),z(ind),'c--');
xlim(tind)
ylim([min(z) max(z)])
l2 = line(get(gca,'XLim'),[1;1]*F,'color','k','linestyle',':')
line([1;1]*tind,[min(z)-3,max(z)+3],'color','r','linestyle','--')
box off
set (gca,'YTicklabel',[],'YColor','none')
xlabel(['Time (sec)'])
   

