function [s_n, TCM] = update_state_elongation(u,PT,log_PT,cn,ext,tau,lstar,options)
%keyboard
 IT                    = PT(options.M+1,:) ;
 log_IT                = log(IT);
 V                     = PT;
 V(options.M+1,:)      = [];
 MT                    = V';
log_MT                 = log(MT);

Diag                   = diag(ones(options.M,1));
SubD1                  = diag([ones(options.M-3,1);1],-2);
SubD                   = diag([ones(options.M-2,1);1],-1);
SupD                   = diag([ones(options.M-2,1);1],1);
SupD1                  = diag([ones(options.M-3,1);1],2);

logDiag                = logical(Diag(:));
logSubD1               = logical(SubD1(:));
logSubD                = logical(SubD(:));
logSupD                = logical(SupD(:));
logSupD1               = logical(SupD1(:));

log_DT                 = log_MT(logDiag)';
log_DT                 = log_DT'; %Save it as row vectors;;
log_SBMT1              = log_MT(logSubD1)'; %Save it as row vectors;
log_SBMT1              = log_SBMT1';
log_SBMT               = log_MT(logSubD)'; %Save it as row vectors;
log_SBMT               = log_SBMT';
log_SPMT               = log_MT(logSupD)';
log_SPMT               = log_SPMT';
log_SPMT1              = log_MT(logSupD1)';
log_SPMT1              = log_SPMT1';

%%%%%%
N                      = length(u);
M                      = length(log_DT);
LD                     = zeros(M,N);
LD  = -(0.5)*(tau)*(bsxfun(@minus,u,(lstar+ext'))).^2;
if any(isnan(LD(:)))
    keyboard
end

LD(:,1)  =  LD(:,1) + log_IT';

%% Forward Filtering
for n = 2 : +1 : options.N
    switch cn(n)+1
        case 1
        LD(:,n)             = LD(:,n) + LD(:,n-1) ;
        case 2
        %% second until the options.M-1 row operations
        sorted_all          = sort([( log_SBMT1(1:M-4,1)+LD(1:M-4,n-1) ) ( log_SBMT(2:M-3,1)+LD(2:M-3,n-1) ) ( log_DT(3:M-2,1)+LD(3:M-2,n-1) ) ( log_SPMT(3:M-2,1)+LD(4:M-1,n-1) ) ( log_SPMT1(3:M-2,1)+LD(5:M,n-1) ) ],2,'descend');
        LD(3:M-2,n)         = (LD(3:M-2,n)) + ( (sorted_all(:,1) + log1p(exp(sorted_all(:,2)-sorted_all(:,1))+ exp(sorted_all(:,3)-sorted_all(:,1)) + exp(sorted_all(:,4)-sorted_all(:,1))+exp(sorted_all(:,5)-sorted_all(:,1)) )) ); 
        %% first and last row operations:
        max_first           = sort([( log_DT(1,1)+LD(1,n-1) ) ( log_SPMT(1,1)+LD(2,n-1) ) ( log_SPMT1(1,1)+LD(3,n-1) )],2,'descend');
        LD(1,n)             = LD(1,n) + max_first(1,1) +log1p(exp(max_first(1,2) -max_first(1,1)) + exp(max_first(1,3) -max_first(1,1)));

        max_second          = sort([ ( log_SBMT(1,1)+LD(1,n-1) ) ( log_DT(2,1)+LD(2,n-1) ) ( log_SPMT(2,1)+LD(3,n-1) ) ( log_SPMT1(2,1)+LD(4,n-1) )],2,'descend');
        LD(2,n)             = LD(2,n) + max_second(1,1) +log1p(exp(max_second(1,2) -max_second(1,1)) + exp(max_second(1,3) -max_second(1,1)) + exp(max_second(1,4) -max_second(1,1)));

        max_f_last          = sort([( log_DT(M-1,1)+LD(M-1,n-1) ) ( log_SBMT(M-2)+LD(M-2,n-1) ) ( log_SBMT1(M-2,1)+LD(M-2,n-1) )  ( log_SPMT(M-1,1)+LD(M,n-1) )],2,'descend');
        LD(M-1,n)           = LD(M-1,n) + max_f_last(1,1) +log1p(exp( max_f_last(1,2) - max_f_last(1,1) ) + exp( max_f_last(1,3) - max_f_last(1,1)) + exp( max_f_last(1,4) - max_f_last(1,1) ));  

        max_last            = sort([( log_DT(M,1)+LD(M,n-1) ) ( log_SBMT(M-1)+LD(M-1,n-1) ) ( log_SBMT1(M-2,1)+LD(M-2,n-1) )],2,'descend');
        LD(M,n)             = LD(M,n) + max_last(1,1) +log1p(exp( max_last(1,2) - max_last(1,1) ) + exp( max_last(1,3) - max_last(1,1) ));  

    end
end
if any(isnan(LD(:)))
    keyboard
end
%  keyboard
 %% Backward Sampling
  s_n     = nan(1,N);
  s_n(N)  = gumble_sample( LD(:,N) );
  log_MT            = log_MT';
log_SBMT1           = log_MT(logSubD1)'; %Save it as row vectors;
log_SBMT            = log_MT(logSubD)'; %Save it as row vectors;
log_SPMT            = log_MT(logSupD)';
log_SPMT1           = log_MT(logSupD1)';
log_DT              = log_DT';
 for n = options.N-1 : -1 : 1
     switch cn(n)+1
         case 2
          switch s_n(n+1)

              case options.M
           s_n(n)  = gumble_sample([LD(options.M-2,n)+log_SPMT1(1,options.M-2);...
                     LD(options.M-1,n)+log_SPMT(1,options.M-1); LD(options.M,n)+log_DT(1,options.M)]);
           switch s_n(n)
               case 2
               s_n(n) = s_n(n+1)-1 ;
               case 1
               s_n(n) = s_n(n+1) -2;
               case 3
               s_n(n) = s_n(n+1);
           end 
              case (options.M-1)
           s_n(n)  = gumble_sample( [LD(options.M-3,n)+log_SPMT1(1,options.M-3); LD(options.M-2,n)+log_SPMT(1,options.M-2);...
                      LD(options.M-1,n)+log_DT(1,options.M-1); LD(options.M,n)+log_SBMT(1,options.M-1)] );
           switch s_n(n)
               case 2
               s_n(n) = s_n(n+1) -1;
               case 1
               s_n(n) = s_n(n+1) -2;
               case 3
               s_n(n) = s_n(n+1);
               case 4
               s_n(n) = s_n(n+1) +1;
            end 
              case (2)
           s_n(n)  = gumble_sample(  [LD(1,n)+log_SPMT(1,1);...
                    LD(2,n)+log_DT(1,2);LD(3,n)+log_SBMT(1,2); LD(4,n)+log_SBMT1(1,2)]);
           switch s_n(n)
               case 1
               s_n(n) = s_n(n+1) -1;
               case 2
               s_n(n) = s_n(n+1);
               case 3
               s_n(n) = s_n(n+1) +1;
               case 4
               s_n(n) = s_n(n+1) +2;   
           end 
              case (1)
    %         p1     = [log_DT(1,1);log_SBMT(1,1);log_SBMT1(1,1)];
    %        lp1     = [LD(1,n);LD(2,n); LD(3,n)];
           s_n(n)  = gumble_sample([LD(1,n)+log_DT(1,1);LD(2,n)+log_SBMT(1,1); LD(3,n)+log_SBMT1(1,1)]);   
           switch s_n(n)
               case 1
               s_n(n) = s_n(n+1) ;
               case 2
               s_n(n) = s_n(n+1) +1;
               case 3
               s_n(n) = s_n(n+1) +2;  
            end 
              otherwise 
              s_n(n) = gumble_sample( LD(s_n(n+1)-2:s_n(n+1)+2,n)+...
                      [log_SPMT1(1,s_n(n+1)-2);log_SPMT(1,s_n(n+1)-1);log_DT(1,s_n(n+1));log_SBMT(1,s_n(n+1));log_SBMT1(1,s_n(n+1))]);
           switch s_n(n)
               case  2
               s_n(n) = s_n(n+1) -1;
               case 1
               s_n(n) = s_n(n+1) -2;
               case 3
               s_n(n) = s_n(n+1);
               case 4
               s_n(n) = s_n(n+1) +1;
               case 5
               s_n(n) = s_n(n+1) +2; 
           end 
          end
         case 1
             s_n(n) = s_n(n+1);
%           switch s_n(n+1)
% 
%               case options.M
%            s_n(n)  = gumble_sample([LD(options.M-2,n);...
%                      LD(options.M-1,n); LD(options.M,n)]);
%            switch s_n(n)
%                case 2
%                s_n(n) = s_n(n+1)-1 ;
%                case 1
%                s_n(n) = s_n(n+1) -2;
%                case 3
%                s_n(n) = s_n(n+1);
%            end 
%               case (options.M-1)
%            s_n(n)  = gumble_sample( [LD(options.M-3,n); LD(options.M-2,n);...
%                       LD(options.M-1,n); LD(options.M,n)] );
%            switch s_n(n)
%                case 2
%                s_n(n) = s_n(n+1) -1;
%                case 1
%                s_n(n) = s_n(n+1) -2;
%                case 3
%                s_n(n) = s_n(n+1);
%                case 4
%                s_n(n) = s_n(n+1) +1;
%             end 
%               case (2)
%            s_n(n)  = gumble_sample(  [LD(1,n);...
%                     LD(2,n);LD(3,n); LD(4,n)]);
%            switch s_n(n)
%                case 1
%                s_n(n) = s_n(n+1) -1;
%                case 2
%                s_n(n) = s_n(n+1);
%                case 3
%                s_n(n) = s_n(n+1) +1;
%                case 4
%                s_n(n) = s_n(n+1) +2;   
%            end 
%               case (1)
%     %         p1     = [log_DT(1,1);log_SBMT(1,1);log_SBMT1(1,1)];
%     %        lp1     = [LD(1,n);LD(2,n); LD(3,n)];
%            s_n(n)  = gumble_sample([LD(1,n);LD(2,n); LD(3,n)]);   
%            switch s_n(n)
%                case 1
%                s_n(n) = s_n(n+1) ;
%                case 2
%                s_n(n) = s_n(n+1) +1;
%                case 3
%                s_n(n) = s_n(n+1) +2;  
%             end 
%               otherwise 
%               s_n(n) = gumble_sample( LD(s_n(n+1)-2:s_n(n+1)+2,n)+...
%                       [0;0;0;0;0]);
%            switch s_n(n)
%                case  2
%                s_n(n) = s_n(n+1) -1;
%                case 1
%                s_n(n) = s_n(n+1) -2;
%                case 3
%                s_n(n) = s_n(n+1);
%                case 4
%                s_n(n) = s_n(n+1) +1;
%                case 5
%                s_n(n) = s_n(n+1) +2; 
%            end 
%           end
     end
 end

%% State Transition Counting
TCM = zeros( M + 1, M );

TCM( M +1, s_n(1) ) = 1;
for n = 2:N
    TCM( s_n(n-1), s_n(n) ) = TCM( s_n(n-1), s_n(n) ) + 1;
end 
