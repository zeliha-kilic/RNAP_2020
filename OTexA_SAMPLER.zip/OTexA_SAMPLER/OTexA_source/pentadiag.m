function P1 = pentadiag(M,a,b,c)

if nargin<1

M = 13;%(+6)
c = 0.99999;
b = 0.999;
a = 0.99;

else
    
if nnz(mod(M,2))
    tag = 1;
else
    tag = 2;
end

switch tag
    
    case 1 % M is odd
        
    sp2  =     ([(2/3)*(1-a);
                 (4/6)*(1-a);
                 (9/12)*(1-a)*ones((M-4)/3,1);
                 (9/12)*(1-b)*ones((M-4)/3,1);
                 (9/12)*(1-c)*ones((M-4)/3,1);
                  0; 
                  0]);
    sp2  =   diag(sp2(find(sp2>eps)),2);

    sp1  =      [(1/3)*(1-a);
                 (1/6)*(1-a);
                 (1/12)*(1-a)*ones((M-4)/3,1);
                 (1/12)*(1-b)*ones((M-4)/3,1);
                 (1/12)*(1-c)*ones((M-4)/3,1);
                 (5/7)*(1-c);
                 0];
    sp1  =   diag(sp1(find(sp1>eps)),1);
    
    d    =      [(a)*ones(2,1);
                 (a)*ones((M-4)/3,1);
                 (b)*ones((M-4)/3,1);
                 (c)*ones((M-4)/3,1);
                 (c)*ones(2,1)];
    d    = diag(d(find(d>eps)));
    
    sb1  =    [0;
              (1/6)*(1-a);
              (3/24)*(1-a)*ones((M-4)/3,1);
              (3/24)*(1-b)*ones((M-4)/3,1);
              (3/24)*(1-c)*ones((M-4)/3,1);
              (1/7)*(1-c);
              (2/3)*(1-c)];
    sb1  = diag(sb1(find(sb1>eps)),-1);
    
    sb2  =     [0;
                0;
                (1/24)*(1-a)*ones((M-4)/3,1);
                (1/24)*(1-b)*ones((M-4)/3,1);
                (1/24)*(1-c)*ones((M-4)/3,1);
                (1/7)*(1-c);
                (1/3)*(1-c);
                ];
    sb2  = diag(sb2(find(sb2>eps)),-2);
    
    P1   = d+sp1+sp2+sb1+sb2;
    
    case 2 % M is even
       
end
end