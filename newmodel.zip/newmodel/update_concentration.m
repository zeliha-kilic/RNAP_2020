function [xi, rho, acc_xi] = update_concentration(s , xi, rho, PT, parameters, acc_xi)
%%State Specific sticky parameter updates
 xi                     = (parameters.tmode * parameters.tmean/(parameters.tmean- parameters.tmode))/(parameters.delta_t);
  rho                   = 1-(parameters.delta_t/parameters.tmean);
 acc_xi                 = 0;

% if isempty(s)
%     rho                  = (1-(parameters.delta_t/parameters.tmean));
%     xi                   = zeros(1,parameters.M +1);
%     xi                   = gamrnd(parameters.a/2,2./(parameters.a .* parameters.b),[1 parameters.M+1]);
%     acc_xi               = zeros(parameters.M+1, 2);
% else 
%  acc_xi                  = zeros(parameters.M+1,2);
%     rho                  = (1-(parameters.delta_t/parameters.tmean));
% %   xi                     = gamrnd((parameters.a/2),2/(parameters.a * parameters.b),[1 parameters.M+1]);
%   rho_old                = rho;
%   xi_old                 = xi';
%  PT(parameters.M+1,:)    = [] ;
%  MT                      = PT';
%  PT                      = [] ;
%  Diag            = diag(ones(parameters.M,1));
%  SubD1           = diag([ones(parameters.M-3,1);1],-2);
%  SubD            = diag([ones(parameters.M-2,1);1],-1);
%  SupD            = diag([ones(parameters.M-2,1);1],1);
%  SupD1           = diag([ones(parameters.M-3,1);1],2);
% %  logDiag         = logical(Diag(:));
% %  logSubD1        = logical(SubD1(:));
% % 
% %  logSubD         = logical(SubD(:));
% %  logSupD         = logical(SupD(:));
% %  logSupD1        = logical(SupD1(:));
%  
%  base                    =  (  diag([1/3;1/4;1/5*ones(parameters.M-4,1);1/4;1/3])+diag([1/3;1/4;1/5*ones(parameters.M-4,1);1/4],1)+diag([1/3;1/4;1/5*ones(parameters.M-4,1)],2)+diag([1/4;(1/5)*ones(parameters.M-4,1);1/4;1/3],-1)+diag([1/5*ones(parameters.M-4,1);1/4;1/3],-2));
%  beta_old_noxi           =  (  (1-rho_old).*base + (rho_old)*( eye( parameters.M,parameters.M ) ) );
%  alpha_old               =  (  xi(1:end-1)  ).*( beta_old_noxi );
% 
%    
%    pi_s                  = [ [ 1;1;MT( logical( SubD1(:) ) ) ] [ 1;MT(logical(SubD(:))) ] MT(logical(Diag(:))) [ MT(logical(SupD(:)));1 ] [ MT(logical(SupD1(:)));1;1 ] ];
% 
% 
%   alphastar_old          = [ [1;1; alpha_old(logical(SubD1(:)))] [1; alpha_old(logical(SubD(:)))] alpha_old(logical(Diag(:))) [alpha_old(logical(SupD(:))); 1]  [alpha_old(logical(SupD1(:)));1;1] ];
% 
%   alphastar_old_zero     = [ [0;0; alpha_old(logical(SubD1(:)))]  [0; alpha_old(logical(SubD(:)))] alpha_old(logical(Diag(:))) [alpha_old(logical(SupD(:))); 0] [alpha_old(logical(SupD1(:)));0;0] ];
% 
%  s_alphastar_old         =  sum( gammaln( alphastar_old ),2 );
%  gamma_alphastar_old     =  gammaln( sum( alphastar_old_zero,2 ) );
%  
%    alphastar_old_xi_zero =  alphastar_old_zero;
%    
%    s_alphastar_old_xi    = s_alphastar_old;
%   gamma_alphastar_old_xi = gamma_alphastar_old;
%  for rep = 1: parameters.xirep
%       xi_prop                 =   ( gamrnd( (parameters.a1/2)',((2*xi_old)./parameters.a1') ,[parameters.M+1 1]) );
% xi_alpha_prop_noxi            =   ( (1-rho).*base + (rho)*( eye( parameters.M,parameters.M ) ) );
% alpha_prop_xi                 =   ( xi_prop(1:end-1) ).*(xi_alpha_prop_noxi ) ;
%      
%       xi_alphastar_prop_zero  =   [ [ 0;0;alpha_prop_xi(logical(SubD1(:))) ] [ 0;alpha_prop_xi(logical(SubD(:))) ] alpha_prop_xi(logical(Diag(:))) [alpha_prop_xi(logical(SupD(:))); 0]  [ alpha_prop_xi(logical(SupD1(:)));0;0]  ];
%       
%       xi_alphastar_prop       =   [ [ 1;1;alpha_prop_xi(logical(SubD1(:))) ] [ 1;alpha_prop_xi(logical(SubD(:))) ] alpha_prop_xi(logical(Diag(:))) [alpha_prop_xi(logical(SupD(:))); 1]  [ alpha_prop_xi(logical(SupD1(:)));1;1]  ];
% 
%       s_xi_alphastar_old_prop =   sum(gammaln( xi_alphastar_prop ),2);
%       xi_gamma_alphastar_prop =   gammaln( sum( xi_alphastar_prop_zero,2 ) );
%            
%       loga1r1                 =   ( parameters.a/2 - (parameters.a1)' ).*( log( xi_prop )-log( xi_old ) );
%       loga1r1(end)            =   [];
%       loga2r1                 =   (xi_prop - xi_old).*( -(parameters.a*parameters.b)/2 + ((parameters.a1)'/2).*( ( xi_prop + xi_old) ./ ( (xi_prop).*(xi_old) ) ) );
%       loga2r1(end)            =   [];
%  	  loga3r                  =   sum(( (xi_alphastar_prop_zero - alphastar_old_xi_zero).*( log(pi_s) )),2);
%       loga4r                  =   xi_gamma_alphastar_prop - s_xi_alphastar_old_prop +  s_alphastar_old_xi  - gamma_alphastar_old_xi;
%       loga5r                  =   loga1r1 + loga2r1 +loga3r +loga4r;
% %       if isequal(loga5r,nan)
% %           keyboard
% %       end
%       loga1r1                 =  [];
%       loga2r1                 =  [];
% 	  loga3r                  =  [];
%       loga4r                  =  [];
%       
%       xi_alpha_prop_noxi      =  [];
%       alpha_prop_xi           =  [];
%     
%       
%       xi_alphastar_prop_zero  =  [];
%       xi_alphastar_prop       =  [];
%       
%       s_xi_alphastar_old_prop =  [];
%       xi_gamma_alphastar_prop =  [];
% 
%       for j = 1:parameters.M
%          if exprnd(1) >-loga5r(j)
%             xi(j)             =  xi_prop(j);
%             acc_xi(j,1)       =  acc_xi(j,1) + 1;
%          end
%             acc_xi(j,2)       =  acc_xi(j,2) + 1;
%       end
% %       acc_xi(j+1) = acc_xi(j+1)+1;
%  end
% end