function [IT,MT,PT,DT,SBMT1,SBMT,SPMT,SPMT1,log_PT,log_MT,log_IT,log_DT,log_SBMT1,log_SBMT,log_SPMT,log_SPMT1]  = update_probs_elongation(IT,MT,options,TCM,u,xi,rho)
%% Actual transition matrix update
  base           = (diag([1/3;1/4;1/5*ones(options.M-4,1);1/4;1/3]) + ...
                    diag([1/3;1/4;1/5*ones(options.M-4,1);1/4],1) + ...
                    diag([1/3;1/4;1/5*ones(options.M-4,1)],2) + ...
                    diag([1/4;(1/5)*ones(options.M-4,1);1/4;1/3],-1) + ...
                    diag([1/5*ones(options.M-4,1);1/4;1/3],-2));
  kappa           = ( xi*(rho-realmin));
              
  TCMp           = TCM(1:options.M,1:options.M);
  [log_MT,MT]    = dirrnd_log_main((TCMp + (kappa)*eye(options.M,options.M)+ ( ( xi )*(1-(rho)) ).*base));
  [log_IT,IT]    = dirrnd_log_init(TCM(options.M+1,:)+(1/options.M)*(ones(1,options.M)));
   PT            = [MT;IT];
   log_PT        = [log_MT;log_IT];
   
   Diag          = diag(ones(options.M,1));
   SubD1         = diag([ones(options.M-3,1);1],-2);
   SubD          = diag([ones(options.M-2,1);1],-1);
   SupD          = diag([ones(options.M-2,1);1],1);
   SupD1         = diag([ones(options.M-3,1);1],2);
   
 logDiag         = logical(Diag(:));
 logSubD1        = logical(SubD1(:));
 logSubD         = logical(SubD(:));
 logSupD         = logical(SupD(:));
 logSupD1        = logical(SupD1(:));
 
 DT              = MT(logDiag)'; %Save it as row vectors;;
 SBMT1           = MT(logSubD1)'; %Save it as row vectors;
 SBMT            = MT(logSubD)'; %Save it as row vectors;
 SPMT            = MT(logSupD)';
 SPMT1           = MT(logSupD1)';
 
 log_DT          = log_MT(logDiag)'; 
 log_SBMT1       = log_MT(logSubD1)';
 log_SBMT        = log_MT(logSubD)';
 log_SPMT        = log_MT(logSupD)';
 log_SPMT1       = log_MT(logSupD1)';



