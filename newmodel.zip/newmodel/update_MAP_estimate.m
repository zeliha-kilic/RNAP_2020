function MAP_est = update_MAP_estimate(log_PT,log_SBMT1,log_SBMT,log_DT,log_SPMT,log_SPMT1,log_IT,xi,rho,s_n,cn,qi,lstar,ext,tau,tau_err,options,u)
 
F_ext          =  (-2:1:options.M-2-1)*(33/100);
  
%% Calculating the part for the likelihood
 part1           = sum( (-( u-(ext(cast(s_n,'single'))+lstar) ).^2*(tau/2) ) )+...
                   (options.N/2)*( log(tau)-log(2*pi) );
               
%% Calculating the part for the incomplete likelihood
    big_alpha    = ( diag([1/3;1/4;1/5*ones(options.M-4,1);1/4;1/3])+...
                    diag([1/3;1/4;1/5*ones(options.M-4,1);1/4],1)+...
                    diag([1/3;1/4;1/5*ones(options.M-4,1)],2)+...
                    diag([1/4;(1/5)*ones(options.M-4,1);1/4;1/3],-1)+...
                    diag([1/5*ones(options.M-4,1);1/4;1/3],-2) );
                                 
 Diag            = diag(ones(options.M,1));
 SubD1           = diag([ones(options.M-3,1);1],-2);
 SubD            = diag([ones(options.M-2,1);1],-1);
 SupD            = diag([ones(options.M-2,1);1],1);
 SupD1           = diag([ones(options.M-3,1);1],2);
 
 logDiag         = logical(Diag(:));
 logSubD1        = logical(SubD1(:));
 logSubD         = logical(SubD(:));
 logSupD         = logical(SupD(:));
 logSupD1        = logical(SupD1(:));
 
 big_alpha_one   = [ [ 1;1; (big_alpha(logSubD1)')' ] [ 1;(big_alpha(logSubD)')' ] (big_alpha(logDiag)')' [ (big_alpha(logSupD)')';1 ]  [ (big_alpha(logSupD1)')';1;1] ];
 big_alpha_zero  = [ [ 0;0; (big_alpha(logSubD1)')' ] [ 0;(big_alpha(logSubD)')' ] (big_alpha(logDiag)')' [ (big_alpha(logSupD)')';0 ]  [ (big_alpha(logSupD1)')';0;0] ];
 logfull_MT      = [ [ 0;0;log_SBMT1'  ] [ 0;log_SBMT'  ]  log_DT'  [ log_SPMT';0 ]  [ log_SPMT1' ;0;0 ] ];

%% Calculating elongation transition probability:
 part311         = ( sum((big_alpha_zero-1).* (logfull_MT),2) );  
 part31          = ( sum(sum((big_alpha_zero-1).* (logfull_MT),2)) );
 part32          = ( sum(gammaln(sum(big_alpha_zero,2)) )-...
                     sum(sum(gammaln(big_alpha_one),2)) );
 part3           = part31 + part32 +  sum( ( (1/options.M)*ones(1,options.M)-1).*log_IT,2 )   ;
    
%% Calculating elongation state contributions 
 
 log_P01 = nan(options.M,options.M,2);
 log_P01(:,:,2) = log_PT(1:options.M,:);
 log_P01(:,:,1) = eps+zeros(options.M);
 
 part21 = sum(log_IT(s_n(1)));
 
 for n = 2:options.N
     part21 = part21 + (log_P01(s_n(n-1),s_n(n),cn(n)+1));
 end
     
%% Calculating on off transition probability controbutions
 q = [1-qi(1) qi(1); 1-qi(2) qi(2);1-qi(3) qi(3)];

 kappa_q  = ( xi * rho ); base_q   = 0.5*ones(2);
                
 alpha_q  = ( xi*(1-rho))*base_q + kappa_q*eye(2,2);
    part6 = sum( sum((alpha_q-1).*log(q(1:2,1:2)),2) ) +...
            sum(base_q(1,:).*q(3,:),2);   
     
%% Calculating on off state contributions
 part41 = (log(q(3,cn(1)+1)));
 
 for n = 2:options.N
     part41 = part41 + (log(q(cn(n-1)+1,cn(n)+1)));
 end

%% Calculating the section of the MAP for the emission parameters
   part51        = ( -gammaln(options.eta/2)-( ( log(2)-log(options.eta*options.beta) )*(options.eta/2) )+...
                   ( ( options.eta/2 - 1 )*log(tau) -( options.eta*options.beta/2 )*(tau) ) );
  part7          = sum( -( (ext-F_ext).^2 )*( tau_err/2 ) +(0.5)*( log(tau_err)-log(2*pi) ) );
 MAP_est         = part1 + part3 + part21 + part6 + part41 + part51 + part7;
