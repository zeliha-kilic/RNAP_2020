function chainstructure_upd = chain_structure_upd(u,samplesize,options,initializedchain,results,results_cw)
profile on
u = double(u);
if samplesize == 0
     timer = tic;
     chainstructure_upd.parameters   = initialize_chain_parameters(options);
     chainstructure_upd.zsample      = [];
     chainstructure_upd.stored       = [];
     chainstructure_upd.gbytes       = 0;
     chainstructure_upd.size         = 1;
     [ chainstructure_upd.zsample ]  = initialize_sampler_upd(u,options,chainstructure_upd.parameters);
     chainstructure_upd.ii           = cast(chainstructure_upd.zsample.ii, 'int16');
     chainstructure_upd.s_n          = cast(chainstructure_upd.zsample.s_n, 'int16');
     chainstructure_upd.ext          = cast(chainstructure_upd.zsample.ext, 'single');
    chainstructure_upd.IT            = cast(chainstructure_upd.zsample.IT, 'double');
     chainstructure_upd.DT           = cast(chainstructure_upd.zsample.DT, 'single');
    chainstructure_upd.SBMT1         = cast(chainstructure_upd.zsample.SBMT1,'single');
     chainstructure_upd.SBMT         = cast(chainstructure_upd.zsample.SBMT,'single');
     chainstructure_upd.SPMT         = cast(chainstructure_upd.zsample.SPMT,'single');
     chainstructure_upd.SPMT1        = cast(chainstructure_upd.zsample.SPMT1,'single');
     chainstructure_upd.tau          = cast(chainstructure_upd.zsample.tau, 'single');
     chainstructure_upd.STCM         = cast(chainstructure_upd.zsample.STCM, 'single');
     
     chainstructure_upd.cn          = cast(chainstructure_upd.zsample.cn, 'int16');
     chainstructure_upd.qi          = cast(chainstructure_upd.zsample.qi, 'single');


    %% Maximum a posteriori initialize
     chainstructure_upd.part6        = cast( chainstructure_upd.zsample.part6, 'single' );
    chainstructure_upd.samplesize    = samplesize;
    if results_cw
        disp(['chain:(total time since the start=' '%0.5f',   num2str(toc(timer)),'s)'])
    end
    elseif samplesize > 0
     timer1 = tic;
     chainstructure_upd.parameters   =  initializedchain.parameters;
     samplesize                      =  (chainstructure_upd.parameters.dissample*samplesize);
     samplesize1                     =  samplesize/(chainstructure_upd.parameters.dissample);
     chainstructure_upd.stored       =  initializedchain.stored;
     chainstructure_upd.gbytes       =  [];
     chainstructure_upd.size         =  initializedchain.size + (samplesize1);
     chainstructure_upd.zsample      =  initializedchain.zsample;
    %% Actual description of s
     chainstructure_upd.ii           =  [initializedchain.ii; nan(ceil(samplesize1),1)];
     chainstructure_upd.s_n          =  [initializedchain.s_n; ones(samplesize, initializedchain.parameters.N, 'like' ,initializedchain.s_n)];
     chainstructure_upd.ext          =  [initializedchain.ext; nan(samplesize,initializedchain.parameters.M, 'like', initializedchain.ext)];
     chainstructure_upd.IT           =  [initializedchain.IT; nan(samplesize,chainstructure_upd.parameters.M,      'like' ,initializedchain.IT)];
     chainstructure_upd.DT           =  [initializedchain.DT; nan(samplesize,chainstructure_upd.parameters.M,'like',initializedchain.DT)];
     chainstructure_upd.SBMT1        =  [initializedchain.SBMT1; nan(samplesize,chainstructure_upd.parameters.M -2,'like',initializedchain.SBMT1)];
     chainstructure_upd.SBMT         =  [initializedchain.SBMT; nan(samplesize,chainstructure_upd.parameters.M -1,'like',initializedchain.SBMT)];
     chainstructure_upd.SPMT         =  [initializedchain.SPMT; nan(samplesize,chainstructure_upd.parameters.M -1,'like', initializedchain.SPMT)];
     chainstructure_upd.SPMT1        =  [initializedchain.SPMT1; nan(samplesize,chainstructure_upd.parameters.M -2,'like', initializedchain.SPMT1)];
     chainstructure_upd.tau          =  [initializedchain.tau; nan(samplesize,1,'like',initializedchain.tau)];
     chainstructure_upd.STCM         =  [initializedchain.STCM; false(samplesize, chainstructure_upd.parameters.M)];
     
     chainstructure_upd.cn          =  [initializedchain.cn; zeros(samplesize, initializedchain.parameters.N, 'like' ,initializedchain.cn)];
     chainstructure_upd.qi          =  [initializedchain.qi; nan(samplesize,3,'like',initializedchain.qi)];

   %% Maximum a posteriori memory allocation
    chainstructure_upd.part6         =  [initializedchain.part6; nan(samplesize,1,'like',initializedchain.part6)];
    if results
        CF_upd = chain_flow_upd( chainstructure_upd,[],u,ceil(initializedchain.size*chainstructure_upd.parameters.dissample)+1);
    end
    counter = initializedchain.size + 1;
    while counter <= chainstructure_upd.size
      [chainstructure_upd.zsample]                       = update_sampler_upd( u,chainstructure_upd.zsample,chainstructure_upd.parameters );
    if  mod( chainstructure_upd.zsample.ii, 1 ) == 0
    chainstructure_upd.ii( counter )                = chainstructure_upd.zsample.ii;
    if  mod( chainstructure_upd.zsample.ii, floor(1/(chainstructure_upd.parameters.dissample))) == 0
    icounter = floor(counter  *(chainstructure_upd.parameters.dissample))+1;
    chainstructure_upd.s_n( icounter , :)           = chainstructure_upd.zsample.s_n;
    chainstructure_upd.ext( icounter , :)           = chainstructure_upd.zsample.ext;
    chainstructure_upd.IT( icounter , :)            = chainstructure_upd.zsample.IT;
    chainstructure_upd.DT( icounter , :)            = chainstructure_upd.zsample.DT;
    chainstructure_upd.SBMT1( icounter , :)          = chainstructure_upd.zsample.SBMT1;   
    chainstructure_upd.SBMT( icounter , :)          = chainstructure_upd.zsample.SBMT;   
    chainstructure_upd.SPMT( icounter , :)          = chainstructure_upd.zsample.SPMT;
    chainstructure_upd.SPMT1( icounter , :)          = chainstructure_upd.zsample.SPMT1;   
    chainstructure_upd.tau( icounter )              = chainstructure_upd.zsample.tau;
    chainstructure_upd.STCM( icounter , :)          = chainstructure_upd.zsample.STCM;
    
     chainstructure_upd.cn( icounter , :)           = chainstructure_upd.zsample.cn;
    chainstructure_upd.qi( icounter , :)            = chainstructure_upd.zsample.qi;

    %% Maximum a posteriori updates
    chainstructure_upd.part6(  icounter  )          = chainstructure_upd.zsample.part6;
    end
    if results
        chain_flow_upd(chainstructure_upd,CF_upd,u,ceil(chainstructure_upd.zsample.ii*chainstructure_upd.parameters.dissample))
    end
    if results_cw
    disp( [ 'iter numb: i = ', num2str( counter) ] )
    end
    counter = counter +1;
    end
    end
  if results_cw
    disp(['chain:(total time since the start=' '%0.5f'  num2str(toc(timer1)),'s)'])
  end
end
%% get the size of the chain
  chainstructure_upd.gbytes  = (bytesforstruct(chainstructure_upd))/(2^(30));

end

function bytes = bytesforstruct(x)
    w = whos('x');
    bytes = w.bytes / numel(x);
end