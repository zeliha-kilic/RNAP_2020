function p =betarn(a,b)

rs1  = gamrnd(a,1);
rs2  = gamrnd(b,1);
p    = rs1./(rs1+rs2);


