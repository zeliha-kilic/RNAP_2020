function thinned_data = thin_data(data,dr)
for m = 1:floor(dr*length(data.s(:,1)))
thinned_data.ext(m,:)  =  data.ext(1/dr *m,:);
thinned_data.s(m,:)    =  data.s(1/dr*m,:);
thinned_data.maxpost(m)    =  data.maxpost(1/dr*m);
thinned_data.zext(m,:) =  thinned_data.ext(m,thinned_data.s(m,:));
thinned_data.tau(m)    =  data.tau(1/dr*m);
thinned_data.parameters = data.parameters;
end
