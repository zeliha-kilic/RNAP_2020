%% LOAD DATA
load('current_data_set.mat')

addpath('fig')
h1  = figure('Units','inch','Position',[0 0 7 5])

ax1= subplot(3,3,[1 2 4 5])

N = size(ground.s,2);
lstar = 8;
s1 = ground.s;
c1 = ground.c;
ttable = (1:1:N)*ground.dt;
t_final = ttable(end);
F = ground.F;

h = plot(ttable, (F(s1)+lstar), 'b.-',...
         ttable, z,'c.-');
     
xlim([0 t_final+ground.dt])
ylim([min(z)-eps max(z)+eps])
legend([h(1) h(2)],'RNAP motion','Simulated data','orientation','vertical','location','SE');uistack(h(1),'top');
ylabel(['Extension (nm)'])


ax2 = subplot(3,3,[7 8])
h_o = stairs(ttable, 1+c1, 'b.-');

xlim([0 t_final+ground.dt])
ylim([.8 2.2])
l2 = legend([h_o(1)],'On-Off pathway dynamics','orientation','vertical','location','southeastoutside');uistack(h(1),'top');
l2.Position = [0.694094844652555,0.187500001827166,0.249266856969976,0.03124999931703];
yticklabels({'off','','on'})
ylabel(['Pathway\newlinedynamics'])
xlabel(['Time (sec)'])

ax3= subplot(3,3,[3 6])
ylim(get(gca,'YLim'))

histogram(z,linspace(min(z),max(z),100),'orientation','horizontal','normalization','pdf','FaceColor',get(h(2),'color'));
ylim([min(z)-eps max(z)+eps])
xlabel(['PDF'])

linkaxes([ax1,ax3],'y')
linkaxes([ax1,ax2],'x')

