function zsample = initialize_sampler_upd(u,options,parameters)
% options.N = length(u);
zsample.ii       = 0;
zsample.u        = u;
zsample.acc_xi   = 0; 
zsample.acc_r    = 0;
%% Actual 's' definition 
zsample.s_n      = cast( ones(1,options.N),'int16');
zsample.part6    = 0;
%% Concentration and self-transition proportion parameter(rho)
%% Base for sparse?? Dirichlet model
%% Splitting the transition matrix into diagonal_subdiagonal_superdiagonal
Diag                 = diag(ones(options.M,1));
SubD1                = diag([ones(options.M-3,1);1],-2);
SubD                 = diag([ones(options.M-2,1);1],-1);
SupD                 = diag([ones(options.M-2,1);1], 1);
SupD1                = diag([ones(options.M-3,1);1], 2);
logDiag              = logical( Diag(:) );
logSubD1             = logical( SubD1(:) );
logSubD              = logical( SubD(:) );
logSupD              = logical( SupD(:) );
logSupD1             = logical( SupD1(:) );
zsample.F_ext        = zeros(1,options.M );
zsample.tau_err      = nan(1, 1 );
zsample.ext          = nan(1, options.M );
zsample.z_ext        = zeros(1,options.N );

zsample.cn           = [cast( ones(1,options.N-5),'int16')  zeros(1,5)];
zsample.qi           = ones(1,3);

%% Following is how I initialize my matrices normally
[zsample.xi,zsample.rho, ~]       = update_concentration([],[],[],[],options,zsample.acc_xi);
[zsample.log_MT,zsample.MT]       = dirrnd_log_main( (zsample.xi*(zsample.rho))*eye(options.M,options.M) +(zsample.xi*(1-zsample.rho)).*((diag([1/3;1/4;1/5*ones(options.M-4,1);1/4;1/3])+diag([1/3;1/4;1/5*ones(options.M-4,1);1/4],1)+diag([1/3;1/4;1/5*ones(options.M-4,1)],2)+diag([1/4;(1/5)*ones(options.M-4,1);1/4;1/3],-1)+diag([1/5*ones(options.M-4,1);1/4;1/3],-2))));
[zsample.log_IT,zsample.IT]       = dirrnd_log_init((1/options.M)*(ones(1,options.M)));
zsample.log_PT                    = [zsample.log_MT;zsample.log_IT];       
zsample.DT                        = zsample.MT( logDiag )'; %Save it as row vectors;
zsample.log_DT                    = zsample.log_MT( logDiag )';
zsample.SBMT                      = zsample.MT( logSubD )'; %Save it as row vectors;
zsample.SBMT1                     = zsample.MT( logSubD1 )'; %Save it as row vectors;
zsample.log_SBMT                  = zsample.log_MT( logSubD )';
zsample.log_SBMT1                 = zsample.log_MT( logSubD1 )';
zsample.SPMT                      = zsample.MT( logSupD )';
zsample.SPMT1                     = zsample.MT( logSupD1 )';
zsample.log_SPMT                  = zsample.log_MT( logSupD )';
zsample.log_SPMT1                 = zsample.log_MT( logSupD1 )';
zsample.STCM                      = false( 1,options.M );
zsample.STCM(1)                   = true;
zsample.PT                        = [zsample.MT;zsample.IT];
[zsample.ext,zsample.F_ext, zsample.tau, zsample.lstar,zsample.tau_err]     = update_emission_adj([],[],[],[],[],options);