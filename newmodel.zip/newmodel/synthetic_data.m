function [ground,z] = synthetic_data(tag)
addpath('pentadiag')
if isequal(tag,1)
    M    = 451;%total number of states,length of the his plasmids
    tau1 = 1;%variance of the measurement noise
    tau  = 1/(0.33)^2; %this is the precision(nm^-2)
    tau_err = 1/(1/100)^2;
    lstar = 8;
    mu  = 0.5;%mean of the measurement(nm)
    eta = 3;
    beta= 0.1;
    l_const = 33/100;%constant periodicity(nm)
    t_final = 100;%final time of the elongation in seconds
    t_dwell = .007;%dwell time in a state
    dt = 0.00125;%data acquisition time stepping in seconds
    p0 = 1; %this is also in bps, location of the promoter
end
N       = floor(t_final/dt);
ttable  = (1:N)*dt;

%% Transition matrix for elongstion on ON-Pathway
c       = 0.995;
b       = 0.99;
a       = 0.99;
%keyboard
P1      = pentadiag(M,a,b,c);
IC      = ( (1/M)*( ones(1,M) ) );%Initial condition
P_on    = [P1; IC]; %augmented transition matrix

%% Transition matrix for elongation on OFF-Pathway
P_off = [eye(M);IC];

%% Success probability for transitions between ON and OFF pathway dynamics
q_11 = 0.9999;   % 1->1 remaining to on starting from on
q_01 = 0.0001;  % 0->1 returning to on starting from off
q_0 = 0.99;      % *->1;
q = [q_01 q_11 q_0];

%% On-Off Pathway dynamics/Elongation Dynamics
c1 = nan(1,N);
c1(1) = ( rand(1) <=  q_0);

s1 = nan(1,N);
s1(1) = sample_categorical(IC);

for n = 2:N

  s1(n) = sample_categorical(c1(n-1)*P_on(s1(n-1),:)+(1-c1(n-1))*P_off(s1(n-1),:));%it samples based onthe rows of the transition matrix

    if c1(n-1)
        c1(n) = ( rand(1) <= q_11 );
    else
        c1(n) = ( rand(1) <= q_01 );
    end
       
end

%% Extension of the linker
F       = (0:M-1)*(33/100);

TCM = zeros( M + 1, M );
TCM( M +1, s1(1) ) = 1;
for n   = 2:N
  TCM( s1(n-1), s1(n) ) = TCM( s1(n-1), s1(n) ) + 1;
end

TCM_c = zeros( M + 1, M );
TCM_c( 2, c1(1)+1 ) = 1;
for n   = 2:N
  TCM_c( c1(n-1)+1, c1(n)+1 ) = TCM_c( c1(n-1)+1, c1(n)+1 ) + 1;
end

%% Measurement of the extension of the tether
z       = nan(1,N);
sigma   = 1/sqrt(tau);
z(1)    = (lstar + F(s1(1))+ sigma*randn(1));
for n   = 2:N
  z(n)  = (F(s1(n))) + lstar + sigma * randn(1); %RNAP elongation(nm)
end


ground.s      = s1;
ground.c      = c1;
ground.TCM    = TCM;
ground.TCM_c  = TCM_c;
ground.F      = F;
ground.M      = M;
ground.IC     = IC;
ground.P      = P_on;
ground.q      = q;
ground.dt     = dt;

%% Plotting the data
%keyboard
tind    = t_final-([100 1]+40)*t_dwell;
%ind     = ttable>=tind(1) & ttable<=tind(2);

addpath('fig')

figure('Units','inch','Position',[0 0 7 5])

ax1= subplot(3,3,[1 2 4 5])
h = plot(ttable, (F(s1)+lstar), 'b.-',...
         ttable, z,'c.-');
     
xlim([0 t_final+dt])
ylim([min(z)-eps max(z)+eps])
legend([h(1) h(2)],'RNAP motion','Simulated data','orientation','vertical','location','SE');uistack(h(1),'top');
ylabel(['Extension (nm)'])


ax2 = subplot(3,3,[7 8])
h_o = stairs(ttable, 1+c1, 'b.-');

xlim([0 t_final+dt])
ylim([.8 2.2])
l2 = legend([h_o(1)],'On-Off pathway dynamics','orientation','vertical','location','southeastoutside');uistack(h(1),'top');
l2.Position = [0.694094844652555,0.187500001827166,0.249266856969976,0.03124999931703];
yticklabels({'off','','on'})
ylabel(['Pathway\newlinedynamics'])
xlabel(['Time (sec)'])

ax3= subplot(3,3,[3 6])
ylim(get(gca,'YLim'))

histogram(z,linspace(min(z),max(z),100),'orientation','horizontal','normalization','pdf','FaceColor',get(h(2),'color'));
ylim([min(z)-eps max(z)+eps])
xlabel(['PDF'])

linkaxes([ax1,ax3],'y')
linkaxes([ax1,ax2],'x')

   

