function parameters = initialize_chain_parameters(options)
parameters.N                 = options.N;
 parameters.tau2             = options.tau2;
parameters.mu2               = options.mu2;
parameters.emissionrepeat    = options.emissionrepeat; 
parameters.M                 = options.M;
parameters.dat               = options.dat;
parameters.eta               = options.eta;
parameters.beta              = options.beta;
parameters.nu                = options.nu;
parameters.theta             = options.theta;
parameters.dissample         = options.dissample;
parameters.a                 = options.a;
parameters.b                 = options.b;
parameters.s1  = options.s1;
parameters.c                 = options.c;
parameters.d                 = options.d;
parameters.phi               = options.phi;
parameters.psi               = options.psi;
parameters.lstar             = options.lstar;
parameters.tmean             = options.tmean;
parameters.tmode             = options.tmode;
parameters.delta_t           = options.delta_t;
parameters.xirep             = options.xirep;

parameters.qi_prior_eta      = options.qi_prior_eta;
parameters.qi_prior_zeta     = options.qi_prior_zeta;

%% Debugging purposes
parameters.ground.cn = options.ground.cn;
parameters.ground.qi = options.ground.qi;
parameters.ground.TCM_c = options.ground.TCM_c;

parameters.ground.sn = options.ground.sn;
parameters.ground.P = options.ground.P;
parameters.ground.TCM = options.ground.TCM;