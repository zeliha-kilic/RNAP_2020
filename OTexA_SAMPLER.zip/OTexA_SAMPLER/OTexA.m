function varargout = OTexA(varargin)
%OTEXA MATLAB code file for OTexA.fig
%      OTEXA, by itself, creates a new OTEXA or raises the existing
%      singleton*.
%
%      H = OTEXA returns the handle to a new OTEXA or the handle to
%      the existing singleton*.
%
%      OTEXA('Property','Value',...) creates a new OTEXA using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to OTexA_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      OTEXA('CALLBACK') and OTEXA('CALLBACK',hObject,...) call the
%      local function named CALLBACK in OTEXA.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help OTexA

% Last Modified by GUIDE v2.5 22-Mar-2020 17:02:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @OTexA_OpeningFcn, ...
                   'gui_OutputFcn',  @OTexA_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before OTexA is made visible.
function OTexA_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for OTexA
handles.output = hObject;

movegui(gcf,'center')

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes OTexA wait for user response (see UIRESUME)
% uiwait(handles.figure1);
addpath('OTexA_source')

handles.u = [];
handles.chainstructure_upd = [];
set(get(handles.axes1,'xlabel'),'string','Time steps')
set(get(handles.axes1,'ylabel'),'string','Extension (nm)')
set(get(handles.axes2,'xlabel'),'string','Residence time (sec)')
set(get(handles.axes3,'ylabel'),'string','Extension (bp)')
set(get(handles.axes4,'xlabel'),'string','Residence time (sec)')

handles.pushbutton10.Enable = 'on';  %IMPORT
    handles.pushbutton6.Enable = 'off' ; %RESET
    handles.pushbutton7.Enable = 'off' ; %SAMPLE
    handles.pushbutton8.Enable = 'off' ; %RESULTS
    handles.pushbutton9.Enable = 'off' ;%EXPORT
    handles.pushbutton4.Enable = 'off' ;%INITIALIZE
    
    handles.checkbox1.Enable   = 'off' ; 
    handles.checkbox2.Enable   = 'off' ; 

    handles.edit11.Enable      = 'off'  ;
    handles.edit13.Enable      = 'off'  ;

    
    handles.edit1.Enable       = 'on'  ;
    handles.edit2.Enable       = 'on'  ;
    handles.edit3.Enable       = 'on'  ;
    handles.edit4.Enable       = 'on'  ;
 
    handles.pushbutton10.Enable= 'on';  %IMPORT
    handles.edit1.Enable       = 'off'  ;
    handles.edit2.Enable       = 'of'  ;
    handles.edit3.Enable       = 'off'  ;
    handles.edit4.Enable       = 'off'  ;
    
    guidata(hObject,handles)
% --- Outputs from this function are returned to the command line.
function varargout = OTexA_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when figure1 is resized.
function figure1_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.sample_size = str2num(handles.edit11.String)+1;

action = true ;

if ( ~isempty(handles.u) && ~isempty(handles.chainstructure_upd)...
        && handles.sample_size>1 )
    prefer = questdlg({'You are about to delete the generated chain!','Would you like to continue?'},'Removing the chain','Yes','No','No');
    switch prefer
        case 'No'
        action = false;
    end
end
if (action==true)
    handles.chainstructure_upd = [];
    handles.u = [];
    delete(handles.axes1.Children)
    delete(handles.axes2.Children)
    delete(handles.axes3.Children)
    delete(handles.axes4.Children)

    handles.pushbutton10.Enable = 'on';  %IMPORT
    handles.pushbutton6.Enable  = 'off' ; %RESET
    handles.pushbutton7.Enable  = 'off' ; %SAMPLE
    handles.pushbutton8.Enable  = 'off' ; %RESULTS
    handles.pushbutton9.Enable  = 'off' ; %EXPORT
    handles.pushbutton4.Enable  = 'off' ; %INITIALIZE
    
    handles.checkbox1.Enable    = 'off' ; 
    handles.checkbox2.Enable    = 'off' ; 

    handles.edit1.Enable        = 'off'  ;
    handles.edit2.Enable        = 'off'  ;
    handles.edit3.Enable        = 'off'  ;
    handles.edit4.Enable        = 'off'  ;
 
    handles.pushbutton10.Enable = 'on';  %IMPORT
    handles.edit1.Enable        = 'off'      ; %omega
    handles.edit2.Enable        = 'off'       ;  %mu
    handles.edit3.Enable        = 'off'      ; %eta
    handles.edit4.Enable        = 'off'      ; %beta
    
    guidata(hObject,handles)
    
    
end


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
helpdlg({...
'The options for the choice of hyperparameters are standing for:',...
'',...
'1)  \omega',...
'--- precision parameter of the normal prior measurement noise',...
'    default value is squared reciprocal of the range of the imported time series',...
'',...
'2) \mu',...
'--- mean parameter of the normal prior measurement noise',...
'    default value is mean of the imported time series',...
'',...
'3)  \beta',...
'--- scale parameter of the gamma prior measurement noise',...
'    default value is squared reciprocal of the range of the imported time series',...
'',...
'4)  \eta',...
'--- shape parameter of the gamma prior measurement noise',...
'    default value is 2',...
},'RNAP set-up');

% ff = figure('Name','Implementation Steps','NumberTitle','off')

handles.myImage = imread('OTexA_gui.png');

imshow(handles.myImage)
h=msgbox('Follow the steps in the figure for successful implementation','Steps of Implementation','custom',handles.myImage );



% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

feature('DefaultCharacterSet','UTF-8');

    f   = figure('menu','none','toolbar','none');
    fid = fopen('README.txt');
    ph  = uipanel(f,'Units','normalized','position',[0.1 0.1 0.85 0.85],'title',...
                'OTexA LICENCE');
    lbh= uicontrol(ph,'style','listbox','Units','normalized','position',...
        [0 0 1 1], 'FontName','Arial Unicode MS','FontSize',9);

    indic = 1;
    while 1
         tline = fgetl(fid);
         if ~ischar(tline), 
             break
         end
         strings{indic} = tline; 
                  indic = indic + 1;
    end
    fclose(fid);
    set(lbh,'string',strings);
    set(lbh,'Value',1);
    set(lbh,'Selected','on');


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.pushbutton7.Enable = 'off'

drawnow
handles.chainstructure_upd = chain_structure_upd(handles.u, str2num(handles.edit11.String),[],...
     handles.chainstructure_upd, handles.checkbox2.Value, handles.checkbox1.Value);
handles.pushbutton9.Enable = 'on'
%% PLOTTING THE MAP ESTIMATE
%%%%%%%%PART1
axes(handles.axes3)
initial_sample = 1+ ceil(str2num(handles.edit13.String)*str2num(handles.edit11.String)*str2num(handles.edit14.String));
last_sample    = ceil(str2num(handles.edit11.String)*str2num(handles.edit14.String))+1;
all_ind        = handles.chainstructure_upd.part6(initial_sample:(last_sample));
max_ind        = find(all_ind == max( all_ind));
counter        = initial_sample:1:(last_sample);
z_maxpost      = ( mean(handles.u(1:100)) +...
    handles.chainstructure_upd.ext(counter(max_ind),cast(handles.chainstructure_upd.s_n(counter(max_ind),:),'single')) )*(100/33); 
%  plot(1:length(handles.u),(mean(handles.u(1:100))+(handles.s-1)*33/100)*(100/33))
%  hold on
 handles.p1 = plot(1:length(handles.u), z_maxpost,'color','m')
 title(['MAP Estimate'])
 ylabel('Extension (bp)')
 xlabel('Time steps')
 set(gca,'Color',[0.94 0.94 0.94])
 y_limit = get(gca,'YLim');


axes(handles.axes4)
ybins    = linspace(min(min(z_maxpost)),max(max(z_maxpost)),(floor((max(handles.u)-min(handles.u))*(100/33))));

[handles.ph1, ~]         = histcounts(z_maxpost,ybins );
scaled_ph1               = handles.ph1*handles.ground.dt;
handles.ph2              = barh(linspace(ybins(1),ybins(end)-1,length(ybins)-1),scaled_ph1)
handles.ph2(1).FaceColor = get(handles.p1(1),'color');
 ax2                     = ancestor(handles.ph2,'axes')
line(get(gca,'XLim').*[1 1],[1;1]*(floor(min(min(z_maxpost))):1:max(max(z_maxpost))),'color','k','linestyle',':')
%  ax2.FontSize = 20;
%  ax2.XTick= ([50, 150, 200]);
 ax2.YTick = ([])

xlabel('Residence Time (s)')
% ylabel('', 'FontSize',20,'color','k')
xlim([0, max(handles.ph1)*handles.ground.dt+1]);
set(gca,'Color',[0.94 0.94 0.94])
ylim(y_limit);

guidata(hObject,handles)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,pathname] = uiputfile({'*.mat','MAT-files (*.mat)'},'Save the chain','chain.mat')
if ~isempty(filename)
    [~,name,~] = fileparts(filename);
    exportchainstructure(handles.chainstructure_upd,str2num(handles.edit14.String),name)
end


function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
prompt                = {['Enter a value for state number between 1 and  ' handles.edit18.String]};
dlgtitle              = 'State number ';
definput              = {'10'};
opts.Interpreter      = 'tex';
answer                = inputdlg(prompt,dlgtitle,[1 str2num(handles.edit18.String)],...
                                 definput,opts);
handles.edit17.String = answer;


function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Set parameter values to input values
options.lambda             = 1.3;
options.M                  = ceil((options.lambda)*abs( (max(handles.u)-min(handles.u)) )*(100/33) );
options.N                  = cast(length(handles.u),'single');
F                          = (0:options.M-1) * (33/100);
options.dat                = [mean(handles.u), std(handles.u), range(handles.u)]; % data statistics
options.delta_t            = handles.ground.dt;

%% Emission parameters
options.mu                 = str2num( handles.edit2.String );%mean(u);% range(u)Earliar simulations always prior mean =mean(data!)
options.tau1               = str2num( handles.edit1.String );%1/range(u)^2;
options.eta                = str2num( handles.edit3.String );%(2);
options.beta               = str2num( handles.edit4.String );%(.019/2)^2; %Strange choice for no reason! 

%% Transition -Dynamics parameters
options.a                  = 2     ;%prior for xi_prior_(shape,gamma)
options.b                  = 0.0001 ;%prior for xi_prior_(1/scale,gamma)
options.c                  = 1     ;%prior for rho_(shape, beta)
options.d                  = 1     ;%prior for rho_(scale,beta)
options.b1                 = 1     ;%rho proposal_beta_distirbtuion_parameter
options.a1                 = ones(1, options.M+1)*2;%prior for xi_prop(mean of the gamma proposal)

%% Conversion parameters
options.mu2                = mean(handles.u); % mean(data!)
 options.tau2              = 1;
options.eta                = (2);
options.nu                 = (2);
options.theta              = 1; %Strange choice for no reason! 


options.emissionrepeat     = 10;
options.xirep              = 10;
options.dissample          = str2num( handles.edit14.String );
options.s_rep              = 10;

options.phi                = 2;    
options.psi                = 1/(10^8);

options.lstar              = mean(handles.u(1:100));
options.ground             = handles.ground;

%% Dwell Time related quantities 
options.tmean              = 0.25*(handles.ttable(end)-handles.ttable(1));
options.tmode              = 0.126*(handles.ttable(end)-handles.ttable(1));

%% Ground truth for the states
options.units              = handles.units;

%% INITIALIZE CHAIN
handles.chainstructure_upd = chain_structure_upd(handles.u,0,options,[],true,true);

%% CONTROL BUTTONS!
handles.pushbutton4.Enable = 'off';
handles.edit1.Enable       = 'off';
handles.edit2.Enable       = 'off';
handles.edit3.Enable       = 'off';
handles.edit4.Enable       = 'off';
handles.pushbutton6.Enable = 'off';



handles.edit11.Enable      = 'on'  ;
handles.edit13.Enable      = 'on'  ;



handles.checkbox1.Enable   = 'on'; %Sample flow
handles.checkbox2.Enable   = 'on';%Visualize
guidata(hObject, handles);

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
chainstructure_upd.size = str2num(handles.edit11.String)+1;
handles.sample_size     = chainstructure_upd.size;
if ~isempty(handles.u)&&handles.sample_size>1
    choice = questdlg({'You are about to delete the imported data and generated chain.',...
        'Would you like to continue?'},'Removing the data and chain','Yes','No','Yes');
end
    switch choice
        case 'Yes'
            handles.u                   = [];
            % REMOVE the chain will be called
            pushbutton3_Callback(hObject, eventdata, handles);
            delete(handles.axes1.Children)
            delete(handles.axes2.Children)
            handles.axes1.Title         = [];
            handles.pushbutton10.Enable = 'on'; % IMPORT
            handles.pushbutton6.Enable  = 'off'; %RESET
            handles.pushbutton4.Enable  = 'off'; %INITIALIZE
            
            handles.edit1.Enable = 'off';
            handles.edit2.Enable = 'off';
            handles.edit3.Enable = 'off';
            handles.edit4.Enable = 'off';
            
            handles.edit1.String = '..';
            handles.edit2.String = '..';
            handles.edit3.String = '..';
            handles.edit4.String = '..';
            
            guidata(hObject, handles);

end

% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.filename = uigetfile({'*.mat','MAT-files (*.mat)'},'Import Extension Data','MultiSelect','off');
if ~isequal(handles.filename,0)
    data           = load(handles.filename);
    handles.u      = data.z;
    handles.s      = data.ground.s;
    handles.ttable = data.ground.dt*(0:1:length(data.z));
    handles.units  = data.units;
    handles.ground = data.ground;
    handles.lambda = 1.3;
    %SHOW EXTENSION
    axes(handles.axes1)
    line(1:length(handles.u), handles.u,'color',[0.60 0.729 0.867 ])%carolina blue
    y_limit = get(gca,'YLim');
    title(['Imported Extension Data  ',handles.filename],'Interpreter','none')
    axes(handles.axes2)
    ybins = linspace(min(handles.u), max(handles.u),150);
    histogram(handles.u,ybins,'Orientation','horizontal')
    set(gca,'XTickLabel',[],'YTickLabel',[])
    box off     
    set(gca,'Color',[0.94 0.94 0.94])

    

    handles.edit1.String       = num2str(1/((range(handles.u) )^2),'%10.4f'); 
    handles.edit2.String       = num2str(((mean(handles.u(1:100)))),'%10.3f');
    handles.edit3.String       = num2str(2,'%10.3f');
    handles.edit4.String       = num2str(0.1,'%10.3f');
    handles.edit18.String      = num2str(ceil((handles.lambda)*(100/33)*(max(handles.u)-min(handles.u))),'%10.0f');

    % ACTIVATE/DeACTIVATE BUTTONS
    handles.pushbutton10.Enable= 'off';
    handles.edit18.Enable      = 'off';

    handles.pushbutton3.Enable = 'on'; %REMOVE
    handles.pushbutton4.Enable = 'on'; %INITIALIZE
    handles.pushbutton7.Enable = 'on'; %INITIALIZE

    handles.edit1.Enable       ='on'; 
    handles.edit2.Enable       ='on'; 
    handles.edit3.Enable       ='on'; 
    handles.edit4.Enable       ='on'; 
    handles.edit9.Enable       ='on'; 
    handles.edit18.Enable      ='off';

end
guidata(hObject, handles);


function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit18 as text
%        str2double(get(hObject,'String')) returns contents of edit18 as a double


% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
