function [ext_new, F_ext_new,tau_new, lstar_new,tau_err_new] = update_emission_adj(tau_old,ext_old,lstar_old,u,s,options)
if isempty(s)  
   F_ext_new  =  (-2:1:options.M-1) * (33/100);%state extension  
lstar_new     = nan(1,1);
tau_new       = nan(1,1);
tau_err_new   = nan(1,1);
lstar_new     = options.lstar;
tau_new       = rand + 1/gamrnd(((options.eta)/2),(2/(options.eta*options.beta)));
tau_err_new   = gamrnd(((options.phi)/2),(2/(options.phi*options.psi)));
ext_new       = nan(1,options.M);
for j = 1:options.M
ext_new(j)    = F_ext_new(j) + sqrt(1/tau_err_new)*randn;
end
z_new         = [];
else
   tau_new    = nan(1,1);
   F_ext_new  = (-2:1:options.M-2-1)  * (33/100);%state extension  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ext_new   = nan(1,options.M);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  tau_err_new = 1/(0.01*(33/100))^2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for j = 1:options.M
              ind = s==j;
              num = sum(ind);
       ext_new(j) = ( tau_old*( sum( u(ind)) - num*(lstar_old) ) + F_ext_new(j)*tau_err_new )/( tau_old*(num) + tau_err_new ) ; 
       ext_new(j) = ext_new(j)  + sqrt(1/(tau_err_new+tau_old*(num))) *(randn);
            end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     lstar_new = options.lstar;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             tau_new1    =  sum( ( u - ( ext_new(s) + lstar_new) ).^2 );
             tau_new     =  gamrnd(((options.N + options.eta)/2) , (2/(options.eta * options.beta + (tau_new1))));
            %%         Debug Purposes
              z_new      = ext_new(s)' + lstar_new ;

        
        
end

        
