function CF_upd = chain_flow_upd(chainstructure_upd,CF_upd,u,counter)

N = length(u);
if isempty(CF_upd)
    figlab = false;
    figure(111)
    y_lim = [min(u) max(u)];
    
    subplot(4,5,[1 2 3 4  6 7 8 9  11 12 13 14  16 17 18 19])
    CF_upd.p1 = plot(1:N, u,'c-',...
                  1:N, (chainstructure_upd.parameters.lstar+chainstructure_upd.ext(counter,cast((chainstructure_upd.s_n(counter,:)),'single'))),'m.-');
    %                   1:N,(8+(chainstructure_upd.parameters.s1-1)*(33/100)),'b*',...

              if figlab
        text(0.3,0.3,{'CF.p1'},'normalized','FontWeight','Bold','Fontsize',15);
              end
    
    ylabel('Extension')
    xlabel('Time steps')
    ylim( y_lim )
    xlim( [0 N+1])
    line(get(gca,'XLim'),0*[1 1],'color','k','linestyle',':')
    legend('Data','States','location','SE')
    box on
    
    subplot(4,5,[5 10 15 20])
   ybeg = linspace(y_lim(1),y_lim(end),length(chainstructure_upd.zsample.u));
   xbeg = 0*ybeg;
   for j=1: length(chainstructure_upd.s_n(1,:))  
    xbeg(j) = xbeg(j) + (sqrt(chainstructure_upd.tau(counter))/(2*pi))*exp((-(ybeg(j) -...
        chainstructure_upd.parameters.lstar + ...
        chainstructure_upd.ext(counter,cast((chainstructure_upd.s_n(counter,j)),'single'))).^2)*chainstructure_upd.tau(counter)/2);
   end
    CF_upd.ph1(1) = histogram(u,linspace(y_lim(1),y_lim(2),100),'facecolor',get(CF_upd.p1(1),'color'),'orientation','horizontal','normalization','pdf');
 
    CF_upd.p2 = line(xbeg,ybeg);
    ylim([ybeg(1) ybeg(end)]);
    xlim(get(gca,'XLim').*[0.4 0.5])

if figlab
    text(0.5,0.5,{'CF.ph1','CF.p2'},'normalized','FontWeight','Bold','FontSize',15);
end
set(gca,'XTickLabel',[],'YTickLabel',[]);
box off
else
set(CF_upd.p1(2),'YData',(chainstructure_upd.parameters.lstar+chainstructure_upd.ext(counter,cast((chainstructure_upd.s_n(counter,:)),'single'))));



ybeg = (get(CF_upd.p2,'YData'));

xbeg = 0*ybeg;
  for j= 1:length(chainstructure_upd.s_n(1,:))
     xbeg(j) = xbeg(j) + (sqrt(chainstructure_upd.tau(counter))/(2*pi))*exp((-(ybeg(j) -...
         (chainstructure_upd.parameters.lstar+...
         chainstructure_upd.ext(counter,cast((chainstructure_upd.s_n(counter,j)),'single')))).^2)*chainstructure_upd.tau(counter)/2);
  end
 set(CF_upd.p2,'XData',xbeg);
 
end
drawnow

