function [zsample] = update_sampler_upd(u, zsample, options )
options.N   = length(u);
zsample.ii  = zsample.ii + 1;
[zsample.s_n, zsample.TCM]                = state_update_log_collapsed(zsample.u,zsample.PT,zsample.log_PT , zsample.ext,zsample.tau,zsample.lstar,options);
[zsample.IT,  zsample.MT, zsample.PT, zsample.DT, zsample.SBMT1,zsample.SBMT,zsample.SPMT,zsample.SPMT1,zsample.log_PT,zsample.log_MT,zsample.log_IT,zsample.log_DT,zsample.log_SBMT1,zsample.log_SBMT,zsample.log_SPMT,zsample.log_SPMT1] = transition_updates_upd(zsample.IT,zsample.MT,options,zsample.TCM,zsample.u,zsample.xi,zsample.rho);
[zsample.xi, zsample.rho, zsample.stored] = concentration_update(zsample.s_n,zsample.xi,zsample.rho,zsample.PT, options);
for i = 1:options.emissionrepeat
    
[zsample.ext, zsample.F_ext, zsample.tau, zsample.lstar,zsample.tau_err_new] = emission_update_adj(zsample.tau,zsample.ext,zsample.lstar,u, zsample.s_n,options);

end
 clear zsample.MT1;
 summedTCM         = sum(zsample.TCM);
 zsample.STCM      = summedTCM;
%% Calculating the maximum a posteriori
zsample.part6      = MAP_update(zsample.log_SBMT1, zsample.log_SBMT,zsample.log_SPMT,zsample.log_SPMT1, zsample.log_DT,zsample.log_IT,zsample.xi,zsample.rho,zsample.s_n,zsample.TCM,zsample.lstar,zsample.ext,zsample.tau,zsample.tau_err,options,u);
