function [pp,p3] = dirrnd_log_main(rs)
 options.M = length(rs);
 
 Diag            = diag(ones(options.M,1));
 SubD1           = diag([ones(options.M-3,1);1],-2);
 SubD            = diag([ones(options.M-2,1);1],-1);
 SupD            = diag([ones(options.M-2,1);1],1);
 SupD1           = diag([ones(options.M-3,1);1],2);
 
 logDiag         = logical(Diag(:));
 logSubD1        = logical(SubD1(:));
 logSubD         = logical(SubD(:));
 logSupD         = logical(SupD(:));
 logSupD1        = logical(SupD1(:));
 
 DT              = rs(logDiag)'; %Save it as row vectors;;
 SBMT            = rs(logSubD)'; %Save it as row vectors;
 SPMT            = rs(logSupD)';
 SBMT1           = rs(logSubD1)';
 SPMT1           = rs(logSupD1)';
 
  rs             = ([[0;0; SBMT1'] [0;SBMT']  DT' [SPMT';0]  [SPMT1';0;0]]);
  
p = randg(rs)+realmin;
p = bsxfun(@rdivide,p,sum(p,2));
ind = isnan(p(:,1));

if any(ind)
    disp('Dir underflows')
    K = size(rs,2);
    p(ind,:) = zeros(sum(ind),K);
    for k=1:K
        p(ind,k) = betarnd(ab(ind,k),sum(ab(ind,k+1:K),2)+realmin).*(1-sum(p(ind,:),2));
    end
end

if any(isequal(p(:),1))
    p = randg(rs+realmin)+realmin;
    p = bsxfun(@rdivide,p,sum(p,2));
end

p1 = log(p);
pp = zeros(options.M,options.M);
pp = log(pp);

pp(logDiag) = p1(:,3);
pp(logSubD1)= p1(3:end,1);
pp(logSubD) = p1(2:end,2);
pp(logSupD) = p1(1:end-1,4);
pp(logSupD1) = p1(1:end-2,5);
p3 = zeros(options.M,options.M);
p3(logDiag) = p(:,3);
p3(logSubD1)= p(3:end,1);
p3(logSubD) = p(2:end,2);
p3(logSupD) = p(1:end-1,4);
p3(logSupD1)= p(1:end-2,5);

