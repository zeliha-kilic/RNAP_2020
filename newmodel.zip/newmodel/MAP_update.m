function MAP_est = MAP_update(log_SBMT1, log_SBMT,log_SPMT,log_SPMT1,log_DT,log_IT,xi,rho,s_n,TCM,lstar,ext,tau,tau_err,options,u)
  F_ext          =  (-20:1:options.M-1-20)*(33/100);
%% Calculating the maximum a posteriori
%% Calculating the part for the likelihood
 part1           = sum( (-( u-(ext(cast(s_n,'single'))+lstar) ).^2*(tau/2) ) )+...
                   (options.N/2)*( log(tau)-log(2*pi) );
%% Calculating the part for the incomplete likelihood
  kappa          = ( xi * rho );
    base         = ( diag([1/3;1/4;1/5*ones(options.M-4,1);1/4;1/3])+...
                    diag([1/3;1/4;1/5*ones(options.M-4,1);1/4],1)+...
                    diag([1/3;1/4;1/5*ones(options.M-4,1)],2)+...
                    diag([1/4;(1/5)*ones(options.M-4,1);1/4;1/3],-1)+...
                    diag([1/5*ones(options.M-4,1);1/4;1/3],-2) );
     big_alpha   = ( xi*(1-rho))*base +...
                     kappa*eye(options.M,options.M );
 Diag            = diag(ones(options.M,1));
 SubD1           = diag([ones(options.M-3,1);1],-2);
 SubD            = diag([ones(options.M-2,1);1],-1);
 SupD            = diag([ones(options.M-2,1);1],1);
 SupD1           = diag([ones(options.M-3,1);1],2);
 logDiag         = logical(Diag(:));
 logSubD1        = logical(SubD1(:));
 logSubD         = logical(SubD(:));
 logSupD         = logical(SupD(:));
 logSupD1        = logical(SupD1(:));
 big_alpha_one   = [ [ 1;1; (big_alpha(logSubD1)')' ] [ 1;(big_alpha(logSubD)')' ] (big_alpha(logDiag)')' [ (big_alpha(logSupD)')';1 ]  [ (big_alpha(logSupD1)')';1;1] ];
 big_alpha_zero  = [ [ 0;0; (big_alpha(logSubD1)')' ] [ 0;(big_alpha(logSubD)')' ] (big_alpha(logDiag)')' [ (big_alpha(logSupD)')';0 ]  [ (big_alpha(logSupD1)')';0;0] ];
 logfull_MT      = [ [ 0;0;log_SBMT1'  ] [ 0;log_SBMT'  ]  log_DT'  [ log_SPMT';0 ]  [ log_SPMT1' ;0;0 ] ];
   TCMp          = TCM(1:options.M,1:options.M);
 full_TCM        = [ [0;0; (TCMp(logSubD1)')'] [0; (TCMp(logSubD)')'] ( TCMp(logDiag)')' [(TCMp(logSupD)')';0] [(TCMp(logSupD1)')';0;0]];
  part2          = ( sum( sum( ( full_TCM .* (logfull_MT) ),2 ) ) ) +...
                   ( sum( TCM(end).*log_IT ,2 ));

%% Calculating the transition matrix and concentration parameter parts:
    part311      = ( sum((big_alpha_zero-1).* (logfull_MT),2));  
    part31       = ( sum(sum((big_alpha_zero-1).* (logfull_MT),2)) );
    part32       = ( sum(gammaln(sum(big_alpha_zero,2)))-...
                     sum(sum(gammaln(big_alpha_one),2)) );
    part3        = part31 + part32;
%% Calculating the section of the MAP for the emission parameters
   part51        = ( -gammaln(options.eta/2)-( ( log(2)-log(options.eta*options.beta) )*(options.eta/2) )+...
                   ( ( options.eta/2 - 1 )*log(tau) -( options.eta*options.beta/2 )*(tau) ) );
  part7          = sum( -( (ext-F_ext).^2 )*( tau_err/2 ) +(0.5)*( log(tau_err)-log(2*pi) ) );
 MAP_est         = part1 + part2 + part3 + part51 + part7;
