function RNAP_demo(timerange)
%TYPE RNAP_demo('m7pn_r') %this is for the excel file

rng('shuffle')
addpath('experimental_data')
filename               = uigetfile({'*.mat','MAT-files (*.mat)'},'Import Extension Data','MultiSelect','off');

data_folder            = pwd;
filess                 = dir('17*.mat');
timerngs               = xlsread([fullfile(data_folder,timerange),'.xlsx']);
file_name_list         = cell(1,length(filess));
for ii = 1:length(filess)
file_name_list{ii}     = filess(ii).name;
end
    for kk =  input('What is the order of the chosen (filename) in the file_name_list?,Enter: kk=')
          clear sas
          clear options;
          clear u;
          tic
          sas     =  load( fullfile( data_folder, [file_name_list{kk}] ) );
          ttable  =  sas.output.time(timerngs(kk,1):floor(timerngs(kk,2)));
           u      =  ( sas.output.signal(timerngs(kk,1):floor(timerngs(kk,2))) );
options.lstar          = mean(u(1:2000));
options.M              = ceil((1.1)*(max(u)-min(u))*(100/33) );
options.N              = cast(length(u),'single');
F                      = (40:-1:-options.M+1+40) * (33/100);

options.dat            = [mean(u), std(u), range(u)]; % data statistics
options.delta_t        = ttable(2)-ttable(1);

options.phi            =   2;    
options.psi            =   1/(10^8)    ;
% Dwell Time related quantities 
%%%%%%%%%
%%%%%%%%%
options.tmean = 0.25*(ttable(end)-ttable(1));
options.tmode = 0.126*(ttable(end)-ttable(1));
%%%%%%%%%
%%%%%%%%%
 options.tau2          = 1;
options.eta            = (2);
options.beta           = 1/range(u)^2; %Strange choice for no reason! 
options.nu             = (2);
options.theta          = 1; %Strange choice for no reason! 
options.a              = 2 ;%prior for xi_prior_(shape,gamma)
options.b              = .0001 ;%prior for xi_prior_(1/scale,gamma)
options.c              = 1 ;%prior for rho_(shape, beta)
options.d              = 1 ;%prior for rho_(scale,beta)
options.b1             = 1;%rho proposal_beta_distirbtuion_parameter
options.mu2            = mean(u);% range(u)Earliar simulations always prior mean =mean(data!)
options.emissionrepeat = 10;
options.s_rep          = 10;
options.xirep          = 10;
options.dissample      = 1;
SS =1000;
chainstructure_upd     = chain_structure_upd(u,0,options,[],true,true);
 for j=1:20
 chainstructure_upd    = chain_structure_upd(u,SS,[],chainstructure_upd,true,true);
 exportchainstructure(chainstructure_upd,u,chainstructure_upd.parameters.dissample,['file_',num2str(kk),num2str((length(kk))) 'traj_9_',num2str((length(chainstructure_upd.ii)))])
 end
clear sas
clear options;
clear u
% toc
clear ASTCM  DT  IT i parameter output SBMT SPMT STCM ufirst3rd z_ext s maxpost 
    end

