function qi = update_probs_pathway(cn, options)

pm = zeros(3,2);
pm(3,:) = [~cn(1) cn(1)];
cn = cn+1;
for n=2:options.N
    pm( cn(n-1), cn(n)) = pm( cn(n-1), cn(n) ) + 1;
end
cn = cn-1;


%pm(1,1):0->0
%pm(1,2):0->1 qi(1)
%pm(2,1):1->0
%pm(2,2):1->1 qi(2)
%keyboard

rho = 1-(options.delta_t/options.tmean);

xi  = (options.tmode * options.tmean/(options.tmean- options.tmode))/(options.delta_t);
 
kappa = ( xi*(rho-realmin));


% qi = betarnd(( ( xi )*(1-(rho)) )*options.qi_prior_eta  + [ pm(1,2), pm(2,2)+kappa,  cn(1) ] , ...
%             ( ( xi )*(1-(rho)) )*options.qi_prior_zeta  + [ pm(1,1)+kappa, pm(2,1), ~cn(1) ] );
%        
%rng(1,'twister');

% qi = betarnd( options.qi_prior_eta  + [ pm(1,2), pm(2,2),  cn(1) ] , ...
%               options.qi_prior_zeta + [ pm(1,1), pm(2,1), ~cn(1) ] );
  base = 0.5*ones(3,2);
 PT    = dirrnd( (pm + (kappa)*eye(3,2)+ ( ( xi )*(1-(rho)) ).*base) );
 
   
%qi = options.ground.qi;
qi(1) = PT(1,2);
qi(2) = PT(2,2);
qi(3) = PT(3,2);

%  keyboard
