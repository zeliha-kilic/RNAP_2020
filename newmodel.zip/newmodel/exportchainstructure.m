function exportchainstructure( chainstructure,u, downsamprate,nameit)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here

maxsample   = ceil(chainstructure.size*(downsamprate));
minsample   = 1;
samplenum   = 1: 1: maxsample;
mem         = chainstructure.gbytes;
parameters  = chainstructure.parameters;
ext         = chainstructure.ext(samplenum,:);
%xi          = chainstructure.xi(samplenum,:);
% rho         = chainstructure.rho(samplenum,:);
s           = chainstructure.s_n(samplenum,:);
c           = chainstructure.cn(samplenum,:);

% ii          = chainstructure.ii(samplenum);
% s_max       = chainstructure.s_max(samplenum,:);
IT          = chainstructure.IT(samplenum,:);
DT          = chainstructure.DT(samplenum,:);
SBMT        = chainstructure.SBMT(samplenum,:);
SPMT        = chainstructure.SPMT(samplenum,:);
SBMT1       = chainstructure.SBMT1(samplenum,:);
SPMT1       = chainstructure.SPMT1(samplenum,:);

qi          = chainstructure.qi(samplenum,:);
 %B          = chainstructure.B(samplenum);
% lstar       = chainstructure.lstar(samplenum);
tau         = chainstructure.tau(samplenum);
STCM        = chainstructure.STCM(samplenum,:);
% ASTCM       = chainstructure.ASTCM(samplenum,:);
ufirst3rd   = u;
% z_ext       = chainstructure.z_ext(samplenum,:);
maxpost    = chainstructure.part6(samplenum); %No rho
% maxpost2    = chainstructure.part62(samplenum); %Includes rho
% maxpost2    = chainstructure.part62(samplenum); %Includes rho
cd '/home/zkilic/Dropbox (ASU)/zeliha_presselab/RNAP_all_materials/plot_RNAP_material/06_18_RNAP_sim/new_model_2/results' ;
% directory  = ['/home/zkilic/Desktop/zeliha_RNAP_project/Forces/WTb+10/results',nameit,'.mat']
save([nameit,'.mat'],'parameters','maxpost','s','qi','c','ext','mem','tau','IT','DT','SBMT','SPMT','SBMT1','SPMT1','STCM','ufirst3rd','-v7.3');
%v7-3 is for data >2gb
disp([nameit,'.mat','--missionaccomplished']);
cd  '/home/zkilic/Dropbox (ASU)/zeliha_presselab/RNAP_all_materials/plot_RNAP_material/06_18_RNAP_sim/new_model_2' ;
