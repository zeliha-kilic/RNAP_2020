clear all
close all
clc
% [ground,z]  = synthetic_data(1);
load('syntheticdata.mat')
ttable  = ground.dt*(0:1:length(z));
synthetic_data.s       = ground.s;
u                      = z;

options.s1             = synthetic_data.s;
options.lstar          = mean(u(1:100));
options.M              = ceil(((1.1)*(max(u)-min(u)))*100/33);
options.N              = cast(length(u),'single');
F                      = (0:1:options.M-1) * (33/100);
options.dat            = [mean(u), std(u), range(u)]; % data statistics
options.delta_t        = ttable(2)-ttable(1);
options.phi            =   2;    
options.psi            =   1/(10^8)    ;
%%%%%%%%%
%%%%%%%%%
options.tmean = 0.1*(ttable(end)-ttable(1));
options.tmode = 0.01*(ttable(end)-ttable(1));
%%%%%%%%%
%%%%%%%%%
 options.tau2          = 1;
options.eta            = (2);
options.beta           = 1/range(u)^2; %Strange choice for no reason! 

options.qi_prior_eta = ones(1,3);
options.qi_prior_zeta= ones(1,3);

options.nu             = (2);
options.theta          = 1; %Strange choice for no reason! 
options.a              = 2 ;%prior for xi_prior_(shape,gamma)
options.b              = .0001 ;%prior for xi_prior_(1/scale,gamma)
options.c              = 1 ;%prior for rho_(shape, beta)
options.d              = 1 ;%prior for rho_(scale,beta)
options.b1             = 1;%rho proposal_beta_distirbtuion_parameter
options.mu2            = mean(u);% range(u)Earliar simulations always prior mean =mean(data!)
options.emissionrepeat = 10;
options.s_rep          = 10;
options.xirep          = 10;
options.dissample      = 1;
SS = 5000;

%% Ground truth information
options.ground.cn = ground.c;
options.ground.qi = ground.q;
options.ground.TCM_c = ground.TCM_c;

options.ground.sn = ground.s;
options.ground.P  = ground.P;
options.ground.TCM = ground.TCM;

%% Chain RUN

chainstructure_upd     = chain_structure_upd(u,0,options,[],true,true);
 for j=1:20
 chainstructure_upd    = chain_structure_upd(u,SS,[],chainstructure_upd,true,true);
 exportchainstructure(chainstructure_upd,u,chainstructure_upd.parameters.dissample,[  'new_model_081020_1_part2_',num2str((length(chainstructure_upd.ii)))])
 end
 
clear sas
clear options;
clear u
% toc
clear ASTCM  DT  IT i parameter output SBMT SPMT STCM ufirst3rd z_ext s maxpost 
